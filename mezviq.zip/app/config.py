from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: str = "development"
    secret_key: str
    fernet_encryption_key: str

    database_url: str
    supabase_url: str | None = None
    supabase_service_role_key: str | None = None

    vector_backend: str = "pgvector"
    pinecone_api_key: str | None = None
    pinecone_environment: str | None = None

    openai_api_key: str
    anthropic_api_key: str | None = None
    llm_primary: str = "gpt-4o-mini"
    llm_fallback: str = "claude-3-haiku-20240307"
    embedding_model: str = "text-embedding-3-small"

    meta_app_secret: str
    meta_verify_token: str
    meta_graph_api_version: str = "v20.0"

    openai_whisper_model: str = "whisper-1"
    rate_limit_per_minute: int = 30


@lru_cache
def get_settings() -> Settings:
    return Settings()
