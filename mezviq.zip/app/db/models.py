import uuid
import enum
from datetime import datetime

from sqlalchemy import String, Text, ForeignKey, DateTime, Enum, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class SenderType(str, enum.Enum):
    user = "user"
    ai = "ai"
    agent = "agent"


class Tenant(Base):
    """Clients / Brands onboarded onto Mezviq Support."""
    __tablename__ = "tenants"

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # WhatsApp Cloud API credentials (per-tenant)
    whatsapp_phone_number_id: Mapped[str | None] = mapped_column(String(64), unique=True, index=True, nullable=True)
    whatsapp_access_token: Mapped[str | None] = mapped_column(Text, nullable=True)  # stored Fernet-encrypted

    # Widget auth
    widget_client_id: Mapped[str] = mapped_column(String(64), unique=True, index=True, default=lambda: uuid.uuid4().hex)
    allowed_origins: Mapped[str | None] = mapped_column(Text, nullable=True)  # comma-separated, for CORS

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    knowledge_base: Mapped[list["KnowledgeBase"]] = relationship(back_populates="tenant", cascade="all, delete-orphan")
    chat_logs: Mapped[list["ChatLog"]] = relationship(back_populates="tenant", cascade="all, delete-orphan")


class KnowledgeBase(Base):
    """Uploaded client documents (PDF/Excel) mapped to their vector namespace."""
    __tablename__ = "knowledge_base"

    doc_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="CASCADE"), index=True)
    file_name: Mapped[str] = mapped_column(String(512), nullable=False)
    vector_namespace: Mapped[str] = mapped_column(String(128), nullable=False)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    tenant: Mapped["Tenant"] = relationship(back_populates="knowledge_base")


class ChatLog(Base):
    """Per-message audit log across WhatsApp + Widget channels."""
    __tablename__ = "chat_logs"

    chat_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="CASCADE"), index=True)
    sender_id: Mapped[str] = mapped_column(String(128), nullable=False)  # phone number or widget session id
    message: Mapped[str] = mapped_column(Text, nullable=False)
    sender_type: Mapped[SenderType] = mapped_column(Enum(SenderType), nullable=False)
    channel: Mapped[str] = mapped_column(String(16), default="whatsapp")  # whatsapp | widget
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)

    tenant: Mapped["Tenant"] = relationship(back_populates="chat_logs")
