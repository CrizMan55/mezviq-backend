import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.routers import whatsapp, widget, admin, handover
from app.routers.widget import limiter

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Mezviq Support", version="1.0.0")

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# NOTE: in production, replace "*" with each tenant's allowed_origins,
# resolved per-request — see routers/widget.py for the per-tenant lookup.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)

app.include_router(whatsapp.router)
app.include_router(widget.router)
app.include_router(admin.router)
app.include_router(handover.router)


@app.get("/health")
async def health():
    return {"status": "ok"}
