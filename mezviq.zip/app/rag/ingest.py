"""
Ingests a tenant's uploaded PDF/Excel file into the vector store, namespaced
by tenant_id so retrieval never crosses tenant boundaries.
"""
import uuid

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import PGVector
from pypdf import PdfReader
from openpyxl import load_workbook

from app.config import get_settings
from app.db.models import KnowledgeBase
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_settings()

_embeddings = OpenAIEmbeddings(model=settings.embedding_model, api_key=settings.openai_api_key)

_splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=120,
    separators=["\n\n", "\n", ". ", " "],
)


def _extract_text_pdf(file_path: str) -> str:
    reader = PdfReader(file_path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def _extract_text_xlsx(file_path: str) -> str:
    wb = load_workbook(file_path, data_only=True)
    lines = []
    for sheet in wb.worksheets:
        for row in sheet.iter_rows(values_only=True):
            cells = [str(c) for c in row if c is not None]
            if cells:
                lines.append(" | ".join(cells))
    return "\n".join(lines)


async def ingest_document(
    db: AsyncSession,
    tenant_id: uuid.UUID,
    file_path: str,
    file_name: str,
) -> KnowledgeBase:
    if file_name.lower().endswith(".pdf"):
        raw_text = _extract_text_pdf(file_path)
    elif file_name.lower().endswith((".xlsx", ".xls")):
        raw_text = _extract_text_xlsx(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_name}")

    namespace = f"tenant_{tenant_id}"
    chunks = _splitter.split_text(raw_text)

    # Namespaced collection = hard tenant isolation at the vector-store layer.
    store = PGVector(
        connection_string=settings.database_url.replace("+asyncpg", ""),
        embedding_function=_embeddings,
        collection_name=namespace,
    )
    store.add_texts(
        texts=chunks,
        metadatas=[{"tenant_id": str(tenant_id), "source": file_name}] * len(chunks),
    )

    kb_record = KnowledgeBase(
        tenant_id=tenant_id,
        file_name=file_name,
        vector_namespace=namespace,
    )
    db.add(kb_record)
    await db.commit()
    await db.refresh(kb_record)
    return kb_record
