"""
Core RAG query pipeline: tenant-scoped retrieval -> grounded prompt -> LLM.
Falls back from GPT-4o-mini to Claude 3 Haiku on primary-provider failure.
"""
import uuid
import logging

from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import PGVector
from openai import AsyncOpenAI, APIError as OpenAIAPIError
from anthropic import AsyncAnthropic

from app.config import get_settings
from app.rag.prompts import SYSTEM_PROMPT_TEMPLATE, NO_CONTEXT_FALLBACK

logger = logging.getLogger("mezviq.rag")
settings = get_settings()

_embeddings = OpenAIEmbeddings(model=settings.embedding_model, api_key=settings.openai_api_key)
_openai_client = AsyncOpenAI(api_key=settings.openai_api_key)
_anthropic_client = AsyncAnthropic(api_key=settings.anthropic_api_key) if settings.anthropic_api_key else None

MIN_RELEVANCE_SCORE = 0.72  # tune against your embedding model's score distribution
TOP_K = 4


async def retrieve_context(tenant_id: uuid.UUID, query: str) -> tuple[str, bool]:
    """Returns (context_text, has_sufficient_context)."""
    namespace = f"tenant_{tenant_id}"
    store = PGVector(
        connection_string=settings.database_url.replace("+asyncpg", ""),
        embedding_function=_embeddings,
        collection_name=namespace,
    )
    results = store.similarity_search_with_relevance_scores(query, k=TOP_K)
    if not results:
        return "", False

    relevant = [(doc, score) for doc, score in results if score >= MIN_RELEVANCE_SCORE]
    if not relevant:
        return "", False

    context = "\n---\n".join(doc.page_content for doc, _ in relevant)
    return context, True


async def _call_openai(system_prompt: str, user_message: str) -> str:
    resp = await _openai_client.chat.completions.create(
        model=settings.llm_primary,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        temperature=0.3,
        max_tokens=500,
    )
    return resp.choices[0].message.content


async def _call_claude_fallback(system_prompt: str, user_message: str) -> str:
    if not _anthropic_client:
        raise RuntimeError("No fallback LLM configured")
    resp = await _anthropic_client.messages.create(
        model=settings.llm_fallback,
        max_tokens=500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}],
    )
    return "".join(block.text for block in resp.content if block.type == "text")


async def generate_reply(tenant_id: uuid.UUID, company_name: str, user_message: str) -> str:
    context, has_context = await retrieve_context(tenant_id, user_message)

    if not has_context:
        return NO_CONTEXT_FALLBACK.format(company_name=company_name)

    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(company_name=company_name, context=context)

    try:
        return await _call_openai(system_prompt, user_message)
    except OpenAIAPIError as exc:
        logger.warning("OpenAI call failed (%s), falling back to Claude", exc)
        try:
            return await _call_claude_fallback(system_prompt, user_message)
        except Exception:
            logger.exception("Both primary and fallback LLM calls failed")
            return (
                "Sorry, I'm having trouble responding right now — "
                "connecting you with a human agent."
            )
