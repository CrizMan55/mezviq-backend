import shutil
import tempfile
import uuid

from fastapi import APIRouter, Depends, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.db.models import Tenant
from app.security import encrypt_secret
from app.rag.ingest import ingest_document

# In production, protect every route below with a Super Admin auth
# dependency (JWT/session check) — omitted here for brevity.
router = APIRouter(prefix="/admin", tags=["admin"])


@router.post("/tenants")
async def create_tenant(company_name: str = Form(...), db: AsyncSession = Depends(get_db)):
    tenant = Tenant(company_name=company_name)
    db.add(tenant)
    await db.commit()
    await db.refresh(tenant)
    return {"tenant_id": tenant.tenant_id, "widget_client_id": tenant.widget_client_id}


@router.patch("/tenants/{tenant_id}/whatsapp-credentials")
async def set_whatsapp_credentials(
    tenant_id: uuid.UUID,
    phone_number_id: str = Form(...),
    access_token: str = Form(...),
    db: AsyncSession = Depends(get_db),
):
    tenant = await db.get(Tenant, tenant_id)
    tenant.whatsapp_phone_number_id = phone_number_id
    tenant.whatsapp_access_token = encrypt_secret(access_token)  # never store plaintext
    await db.commit()
    return {"status": "updated"}


@router.post("/tenants/{tenant_id}/knowledge-base")
async def upload_knowledge_base(
    tenant_id: uuid.UUID,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file.filename}") as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    kb_record = await ingest_document(db, tenant_id, tmp_path, file.filename)
    return {"doc_id": kb_record.doc_id, "vector_namespace": kb_record.vector_namespace}
