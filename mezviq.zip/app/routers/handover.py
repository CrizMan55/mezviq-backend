import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.db.models import ChatLog

router = APIRouter(prefix="/api/handover", tags=["handover"])

# In production this powers a live agent dashboard — e.g. a websocket
# channel per tenant that pushes flagged/low-confidence conversations,
# plus an endpoint for the agent to send a reply that gets relayed back
# to WhatsApp/Widget the same way generate_reply()'s output does.


@router.get("/{tenant_id}/history/{sender_id}")
async def get_conversation_history(tenant_id: uuid.UUID, sender_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(ChatLog)
        .where(ChatLog.tenant_id == tenant_id, ChatLog.sender_id == sender_id)
        .order_by(ChatLog.timestamp.asc())
    )
    logs = result.scalars().all()
    return [
        {"message": log.message, "sender_type": log.sender_type, "timestamp": log.timestamp}
        for log in logs
    ]
