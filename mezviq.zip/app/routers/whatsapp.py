import json
import logging

import httpx
from fastapi import APIRouter, Request, Response, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.security import verify_meta_signature, decrypt_secret, sanitize_user_input
from app.db.session import get_db
from app.db.models import Tenant, ChatLog, SenderType
from app.rag.pipeline import generate_reply

router = APIRouter(prefix="/webhook/whatsapp", tags=["whatsapp"])
logger = logging.getLogger("mezviq.whatsapp")
settings = get_settings()


@router.get("")
async def verify_webhook(request: Request):
    """Meta's one-time subscription verification handshake."""
    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")

    if mode == "subscribe" and token == settings.meta_verify_token:
        return Response(content=challenge, media_type="text/plain")

    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Verification failed")


@router.post("")
async def receive_message(request: Request, db: AsyncSession = Depends(get_db)):
    # verify_meta_signature reads the raw body AND validates HMAC in one step
    raw_body = await verify_meta_signature(request)
    payload = json.loads(raw_body)

    try:
        entry = payload["entry"][0]
        change = entry["changes"][0]["value"]
        phone_number_id = change["metadata"]["phone_number_id"]
        messages = change.get("messages")
    except (KeyError, IndexError):
        # Status callbacks (delivered/read receipts) land here too — ack and ignore.
        return {"status": "ignored"}

    if not messages:
        return {"status": "ignored"}

    message = messages[0]
    sender_id = message["from"]
    message_type = message.get("type", "text")

    if message_type == "text":
        message_body = message["text"]["body"]
    elif message_type == "audio":
        # Optional voice handling: fetch media, transcribe via Whisper API.
        message_body = await _transcribe_voice_message(message)
    else:
        message_body = None

    if not message_body:
        return {"status": "unsupported_message_type"}

    # 1. Resolve tenant by phone_number_id
    result = await db.execute(select(Tenant).where(Tenant.whatsapp_phone_number_id == phone_number_id))
    tenant = result.scalar_one_or_none()
    if not tenant:
        logger.error("No tenant found for phone_number_id=%s", phone_number_id)
        return {"status": "unknown_tenant"}

    # 2. Sanitize input (prompt-injection guard) before it reaches the LLM
    try:
        clean_message = sanitize_user_input(message_body)
    except ValueError:
        await _log_chat(db, tenant.tenant_id, sender_id, message_body, SenderType.user)
        await _send_whatsapp_message(tenant, sender_id, "Let me connect you with a human agent for this.")
        return {"status": "flagged_for_handover"}

    await _log_chat(db, tenant.tenant_id, sender_id, clean_message, SenderType.user)

    # 3. RAG-grounded reply
    reply_text = await generate_reply(tenant.tenant_id, tenant.company_name, clean_message)

    await _log_chat(db, tenant.tenant_id, sender_id, reply_text, SenderType.ai)

    # 4. Deliver via Meta Send API
    await _send_whatsapp_message(tenant, sender_id, reply_text)

    return {"status": "ok"}


async def _log_chat(db: AsyncSession, tenant_id, sender_id: str, message: str, sender_type: SenderType):
    db.add(ChatLog(tenant_id=tenant_id, sender_id=sender_id, message=message, sender_type=sender_type, channel="whatsapp"))
    await db.commit()


async def _send_whatsapp_message(tenant: Tenant, to: str, body: str):
    access_token = decrypt_secret(tenant.whatsapp_access_token)
    url = (
        f"https://graph.facebook.com/{settings.meta_graph_api_version}"
        f"/{tenant.whatsapp_phone_number_id}/messages"
    )
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": body},
    }
    headers = {"Authorization": f"Bearer {access_token}"}

    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code >= 400:
            logger.error("Meta send API error %s: %s", resp.status_code, resp.text)


async def _transcribe_voice_message(message: dict) -> str | None:
    """Placeholder: download media via Meta Media API, then transcribe with Whisper."""
    # 1. GET https://graph.facebook.com/{version}/{media_id} -> media URL
    # 2. Download the audio binary (with Authorization header)
    # 3. Send to OpenAI Whisper (audio.transcriptions.create)
    logger.info("Voice message received — implement Whisper transcription pipeline")
    return None
