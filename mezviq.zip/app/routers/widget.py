import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.db.session import get_db
from app.db.models import Tenant, ChatLog, SenderType
from app.rag.pipeline import generate_reply
from app.security import sanitize_user_input
from app.schemas import WidgetMessageIn, WidgetMessageOut

router = APIRouter(prefix="/api/widget", tags=["widget"])
limiter = Limiter(key_func=get_remote_address)


@router.post("/message", response_model=WidgetMessageOut)
@limiter.limit("30/minute")
async def widget_message(request: Request, body: WidgetMessageIn, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Tenant).where(Tenant.widget_client_id == body.client_id))
    tenant = result.scalar_one_or_none()
    if not tenant:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown client_id")

    session_id = body.session_id or str(uuid.uuid4())

    try:
        clean_message = sanitize_user_input(body.message)
    except ValueError:
        return WidgetMessageOut(
            session_id=session_id,
            reply="Let me connect you with a human agent for this.",
            handover=True,
        )

    db.add(ChatLog(tenant_id=tenant.tenant_id, sender_id=session_id, message=clean_message,
                    sender_type=SenderType.user, channel="widget"))
    await db.commit()

    reply = await generate_reply(tenant.tenant_id, tenant.company_name, clean_message)

    db.add(ChatLog(tenant_id=tenant.tenant_id, sender_id=session_id, message=reply,
                    sender_type=SenderType.ai, channel="widget"))
    await db.commit()

    return WidgetMessageOut(session_id=session_id, reply=reply, handover=False)
