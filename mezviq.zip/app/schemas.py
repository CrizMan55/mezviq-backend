from pydantic import BaseModel, Field


class WidgetMessageIn(BaseModel):
    client_id: str = Field(..., description="Tenant's public widget_client_id, e.g. data-client-id on the script tag")
    session_id: str | None = Field(None, description="Returned from the previous response; omit on first message")
    message: str = Field(..., min_length=1, max_length=2000)


class WidgetMessageOut(BaseModel):
    session_id: str
    reply: str
    handover: bool = False
