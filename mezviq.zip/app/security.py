import hmac
import hashlib

from cryptography.fernet import Fernet
from fastapi import Request, HTTPException, status

from app.config import get_settings

settings = get_settings()
_fernet = Fernet(settings.fernet_encryption_key.encode() if len(settings.fernet_encryption_key) == 44 else Fernet.generate_key())


def encrypt_secret(plaintext: str) -> str:
    """Encrypt a tenant's WhatsApp access token before persisting it."""
    return _fernet.encrypt(plaintext.encode()).decode()


def decrypt_secret(ciphertext: str) -> str:
    return _fernet.decrypt(ciphertext.encode()).decode()


async def verify_meta_signature(request: Request) -> bytes:
    """
    Validates the X-Hub-Signature-256 header Meta sends on every webhook POST.
    Must run against the RAW request body (before JSON parsing) — recompute
    HMAC-SHA256 using META_APP_SECRET and compare with constant-time compare.
    Raises 401 on mismatch. Returns the raw body for downstream parsing.
    """
    signature_header = request.headers.get("X-Hub-Signature-256")
    if not signature_header or not signature_header.startswith("sha256="):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing signature header")

    body = await request.body()
    expected_sig = hmac.new(
        key=settings.meta_app_secret.encode(),
        msg=body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    provided_sig = signature_header.split("sha256=", 1)[1]

    if not hmac.compare_digest(expected_sig, provided_sig):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid webhook signature")

    return body


def sanitize_user_input(text: str) -> str:
    """
    Lightweight prompt-injection guard: strips common override phrases and
    caps length before the text ever reaches the LLM prompt template.
    This is a defense-in-depth layer, NOT a substitute for the grounding
    rules enforced in rag/prompts.py (system prompt + retrieval-only context).
    """
    max_len = 2000
    text = text.strip()[:max_len]
    danger_markers = [
        "ignore previous instructions",
        "ignore all previous instructions",
        "you are now",
        "system prompt",
        "disregard the above",
    ]
    lowered = text.lower()
    for marker in danger_markers:
        if marker in lowered:
            # Don't silently strip and continue trusting the rest — flag it
            # so the pipeline can route to human handover instead of the LLM.
            raise ValueError("suspicious_input_flagged_for_handover")
    return text
