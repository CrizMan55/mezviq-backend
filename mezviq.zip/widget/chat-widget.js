/**
 * Mezviq Support — Embeddable Chat Widget
 * Usage:
 * <script src="https://cdn.mezviq.online/widget.js" data-client-id="MZ_CLIENT_UNIQUE_ID" async></script>
 */
(function () {
  const currentScript = document.currentScript;
  const CLIENT_ID = currentScript.getAttribute("data-client-id");
  const API_BASE = currentScript.getAttribute("data-api-base") || "https://api.mezviq.online";
  const ACCENT = currentScript.getAttribute("data-accent") || "#128C7E";

  if (!CLIENT_ID) {
    console.error("Mezviq widget: data-client-id is required");
    return;
  }

  let sessionId = null;

  const style = document.createElement("style");
  style.textContent = `
    .mz-launcher {
      position: fixed; bottom: 20px; right: 20px; width: 56px; height: 56px;
      border-radius: 50%; background: ${ACCENT}; box-shadow: 0 4px 14px rgba(0,0,0,.2);
      display: flex; align-items: center; justify-content: center; cursor: pointer;
      z-index: 999998; transition: transform .15s ease;
    }
    .mz-launcher:hover { transform: scale(1.06); }
    .mz-launcher svg { width: 26px; height: 26px; fill: #fff; }
    .mz-panel {
      position: fixed; bottom: 90px; right: 20px; width: 340px; max-width: 92vw;
      height: 460px; max-height: 70vh; background: #fff; border-radius: 14px;
      box-shadow: 0 8px 30px rgba(0,0,0,.25); display: none; flex-direction: column;
      overflow: hidden; z-index: 999999; font-family: -apple-system, Segoe UI, Roboto, sans-serif;
    }
    .mz-panel.open { display: flex; }
    .mz-header { background: ${ACCENT}; color: #fff; padding: 14px 16px; font-weight: 600; font-size: 15px; }
    .mz-messages { flex: 1; overflow-y: auto; padding: 12px; background: #f5f6f7; }
    .mz-msg { max-width: 80%; margin-bottom: 8px; padding: 8px 12px; border-radius: 12px; font-size: 14px; line-height: 1.4; }
    .mz-msg.user { background: ${ACCENT}; color: #fff; margin-left: auto; border-bottom-right-radius: 3px; }
    .mz-msg.ai { background: #fff; color: #222; border: 1px solid #e3e3e3; margin-right: auto; border-bottom-left-radius: 3px; }
    .mz-input-row { display: flex; border-top: 1px solid #eee; padding: 8px; gap: 8px; }
    .mz-input-row input { flex: 1; border: 1px solid #ddd; border-radius: 20px; padding: 8px 14px; font-size: 14px; outline: none; }
    .mz-input-row button { background: ${ACCENT}; color: #fff; border: none; border-radius: 20px; padding: 0 16px; cursor: pointer; font-size: 14px; }
    .mz-input-row button:disabled { opacity: .5; cursor: default; }
  `;
  document.head.appendChild(style);

  const launcher = document.createElement("div");
  launcher.className = "mz-launcher";
  launcher.innerHTML = `<svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>`;

  const panel = document.createElement("div");
  panel.className = "mz-panel";
  panel.innerHTML = `
    <div class="mz-header">Chat with us</div>
    <div class="mz-messages" id="mz-messages"></div>
    <div class="mz-input-row">
      <input type="text" id="mz-input" placeholder="Type a message..." />
      <button id="mz-send">Send</button>
    </div>
  `;

  document.body.appendChild(launcher);
  document.body.appendChild(panel);

  const messagesEl = panel.querySelector("#mz-messages");
  const inputEl = panel.querySelector("#mz-input");
  const sendBtn = panel.querySelector("#mz-send");

  launcher.addEventListener("click", () => {
    panel.classList.toggle("open");
    if (panel.classList.contains("open") && !messagesEl.hasChildNodes()) {
      appendMessage("ai", "Hi! How can I help you today?");
    }
  });

  function appendMessage(role, text) {
    const bubble = document.createElement("div");
    bubble.className = `mz-msg ${role}`;
    bubble.textContent = text;
    messagesEl.appendChild(bubble);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  async function sendMessage() {
    const text = inputEl.value.trim();
    if (!text) return;

    appendMessage("user", text);
    inputEl.value = "";
    sendBtn.disabled = true;

    try {
      const resp = await fetch(`${API_BASE}/api/widget/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          client_id: CLIENT_ID,
          session_id: sessionId,
          message: text,
        }),
      });

      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

      const data = await resp.json();
      sessionId = data.session_id;
      appendMessage("ai", data.reply);
    } catch (err) {
      appendMessage("ai", "Sorry, something went wrong. Please try again in a moment.");
      console.error("Mezviq widget error:", err);
    } finally {
      sendBtn.disabled = false;
    }
  }

  sendBtn.addEventListener("click", sendMessage);
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage();
  });
})();
